# AEGIS
### An Intelligent System for Cloud Application Monitoring and Failure Detection

AEGIS is a student-built monitoring prototype. It collects system resource metrics, applies configurable rule-based thresholds, records history in SQLite, and displays the results in a Flask web dashboard.

> **Current implementation:** CPU, memory and disk monitoring; network traffic counters; threshold-based alerts; SQLite history; dashboard and JSON API.
>
> **Not currently implemented:** machine-learning prediction, guaranteed failure prevention, multi-server orchestration, email notifications, or automatic recovery. These are possible future extensions.

## Features
- Periodic CPU, RAM and disk usage collection
- Network bytes sent/received counters
- Configurable warning and critical thresholds
- Alert creation and automatic resolution when usage returns below warning level
- SQLite storage for historical metrics and alerts
- Web dashboard with live refresh and charts
- JSON endpoints for status, metrics, alerts and health
- Dockerfile for containerised deployment

## Run locally

Python 3.10+ is recommended.

### 1. Create and activate a virtual environment

**Windows**
```bash
python -m venv .venv
.venv\\Scripts\\activate
```

**Linux / macOS**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Start AEGIS
```bash
python app.py
```

Open http://127.0.0.1:5000 in your browser.

The SQLite database `aegis.db` is created automatically.

## Configuration

Set environment variables before starting the app. Defaults are shown below.

| Variable | Default | Meaning |
|---|---:|---|
| `AEGIS_SAMPLE_INTERVAL` | `5` | Seconds between samples |
| `AEGIS_CPU_WARNING` | `80` | CPU warning threshold (%) |
| `AEGIS_CPU_CRITICAL` | `95` | CPU critical threshold (%) |
| `AEGIS_MEMORY_WARNING` | `80` | RAM warning threshold (%) |
| `AEGIS_MEMORY_CRITICAL` | `95` | RAM critical threshold (%) |
| `AEGIS_DISK_WARNING` | `85` | Disk warning threshold (%) |
| `AEGIS_DISK_CRITICAL` | `95` | Disk critical threshold (%) |
| `AEGIS_DATABASE` | `aegis.db` | SQLite database path |
| `AEGIS_HOST` | `127.0.0.1` | Bind address |
| `AEGIS_PORT` | `5000` | Web server port |

For cloud VM access, set `AEGIS_HOST=0.0.0.0`, configure the VM firewall/security group carefully, and use a production WSGI server plus HTTPS before exposing it publicly. Flask's built-in development server is for development only.

## API endpoints

- `GET /api/health` — service health check
- `GET /api/status` — latest sample and summary
- `GET /api/metrics?limit=60` — recent metrics
- `GET /api/alerts?limit=30` — recent alerts

## Docker

Build:
```bash
docker build -t aegis-monitor .
```

Run:
```bash
docker run --rm -p 5000:5000 -v aegis-data:/app/data aegis-monitor
```

Then open http://127.0.0.1:5000.

## Project modules

- `monitor.py` — collects system metrics in a background thread
- `detector.py` — checks metrics against configured thresholds
- `database.py` — stores and retrieves metrics and alerts
- `app.py` — Flask routes and dashboard server
- `templates/index.html` — dashboard structure
- `static/style.css` — dashboard styling
- `static/app.js` — dashboard refresh and chart rendering
- `config.py` — configuration and thresholds

## Important limitations
- This version monitors the machine on which the Python process runs.
- Network figures are cumulative bytes converted to MB, not network speed.
- CPU/RAM/disk thresholds are simple rules and can produce false alarms.
- The dashboard is not protected by login/authentication; do not expose it to the public internet as-is.
- The prototype is not a high-availability production monitoring platform.

## Suggested next improvements
1. Add authentication and role-based access.
2. Add email notifications with securely stored credentials.
3. Monitor application endpoints and response times.
4. Add multi-host agents that securely send metrics to a central server.
5. Add ML-based anomaly detection and evaluate it against labelled test data.
6. Add tests, structured logging, and a production deployment setup.
