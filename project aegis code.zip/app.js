let metricsChart;

function setMetric(name, value) {
  document.getElementById(`${name}-value`).textContent = `${Number(value).toFixed(1)}%`;
  document.getElementById(`${name}-bar`).style.width = `${Math.min(100, Math.max(0, value))}%`;
}

function formatTime(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString();
}

function drawChart(rows) {
  const labels = rows.map(row => new Date(row.timestamp).toLocaleTimeString());
  const data = {
    labels,
    datasets: [
      { label: "CPU %", data: rows.map(r => r.cpu), borderColor: "#66a7ff", tension: .3 },
      { label: "Memory %", data: rows.map(r => r.memory), borderColor: "#4adea3", tension: .3 },
      { label: "Disk %", data: rows.map(r => r.disk), borderColor: "#f6c85f", tension: .3 }
    ]
  };
  if (metricsChart) {
    metricsChart.data = data;
    metricsChart.update();
  } else {
    metricsChart = new Chart(document.getElementById("metrics-chart"), {
      type: "line", data,
      options: {
        responsive: true, animation: false,
        interaction: { intersect: false, mode: "index" },
        plugins: { legend: { labels: { color: "#cbd5e1" } } },
        scales: {
          x: { ticks: { color: "#91a0bd", maxTicksLimit: 8 }, grid: { color: "#26344f" } },
          y: { min: 0, max: 100, ticks: { color: "#91a0bd" }, grid: { color: "#26344f" } }
        }
      }
    });
  }
}

function renderAlerts(alerts) {
  const body = document.getElementById("alerts-body");
  if (!alerts.length) {
    body.innerHTML = '<tr><td colspan="5" class="empty">No alerts recorded.</td></tr>';
    return;
  }
  body.innerHTML = alerts.map(alert => `
    <tr>
      <td>${formatTime(alert.timestamp)}</td>
      <td>${alert.metric}</td>
      <td class="level ${alert.level}">${alert.level}</td>
      <td>${alert.message}</td>
      <td class="${alert.resolved ? "resolved" : "active"}">${alert.resolved ? "Resolved" : "Active"}</td>
    </tr>`).join("");
}

async function refreshDashboard() {
  try {
    const [statusResponse, metricsResponse, alertsResponse] = await Promise.all([
      fetch("/api/status"), fetch("/api/metrics?limit=60"), fetch("/api/alerts?limit=30")
    ]);
    if (!statusResponse.ok || !metricsResponse.ok || !alertsResponse.ok) throw new Error("API request failed");
    const status = await statusResponse.json();
    const metrics = await metricsResponse.json();
    const alerts = await alertsResponse.json();

    if (status.latest) {
      setMetric("cpu", status.latest.cpu);
      setMetric("memory", status.latest.memory);
      setMetric("disk", status.latest.disk);
      document.getElementById("last-updated").textContent = `Last sample: ${formatTime(status.latest.timestamp)}`;
    }
    const active = alerts.filter(a => !a.resolved);
    document.getElementById("alert-count").textContent = active.length;
    const health = document.getElementById("overall-status");
    health.textContent = active.some(a => a.level === "CRITICAL") ? "Critical" : active.length ? "Warning" : "Normal";
    health.style.color = active.some(a => a.level === "CRITICAL") ? "#ff6b7a" : active.length ? "#f6c85f" : "#4adea3";
    drawChart(metrics);
    renderAlerts(alerts);
  } catch (error) {
    document.getElementById("overall-status").textContent = "Connection error";
    document.getElementById("last-updated").textContent = "Could not reach the AEGIS server";
    console.error("AEGIS refresh failed:", error);
  }
}

refreshDashboard();
setInterval(refreshDashboard, 5000);
