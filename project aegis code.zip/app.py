from flask import Flask, jsonify, render_template, request
from monitor import SystemMonitor
from database import init_db, get_latest_metrics, get_metrics, get_alerts, get_summary
from config import HOST, PORT, DEBUG

app = Flask(__name__)
monitor = SystemMonitor()


@app.route("/")
def dashboard():
    return render_template("index.html")


@app.route("/api/status")
def api_status():
    latest = get_latest_metrics()
    return jsonify({
        "status": "online",
        "latest": latest,
        "summary": get_summary()
    })


@app.route("/api/metrics")
def api_metrics():
    try:
        limit = min(max(int(request.args.get("limit", 60)), 1), 500)
    except ValueError:
        limit = 60
    return jsonify(get_metrics(limit))


@app.route("/api/alerts")
def api_alerts():
    try:
        limit = min(max(int(request.args.get("limit", 30)), 1), 200)
    except ValueError:
        limit = 30
    return jsonify(get_alerts(limit))


@app.route("/api/health")
def api_health():
    return jsonify({"ok": True, "service": "AEGIS"})


if __name__ == "__main__":
    init_db()
    monitor.start()
    try:
        app.run(host=HOST, port=PORT, debug=DEBUG, use_reloader=False)
    finally:
        monitor.stop()
