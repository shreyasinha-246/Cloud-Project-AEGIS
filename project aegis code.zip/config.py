import os

HOST = os.getenv("AEGIS_HOST", "127.0.0.1")
PORT = int(os.getenv("AEGIS_PORT", "5000"))
DEBUG = os.getenv("AEGIS_DEBUG", "false").lower() == "true"
SAMPLE_INTERVAL = int(os.getenv("AEGIS_SAMPLE_INTERVAL", "5"))

# Thresholds can be changed using environment variables.
CPU_WARNING = float(os.getenv("AEGIS_CPU_WARNING", "80"))
CPU_CRITICAL = float(os.getenv("AEGIS_CPU_CRITICAL", "95"))
MEMORY_WARNING = float(os.getenv("AEGIS_MEMORY_WARNING", "80"))
MEMORY_CRITICAL = float(os.getenv("AEGIS_MEMORY_CRITICAL", "95"))
DISK_WARNING = float(os.getenv("AEGIS_DISK_WARNING", "85"))
DISK_CRITICAL = float(os.getenv("AEGIS_DISK_CRITICAL", "95"))

DATABASE_PATH = os.getenv("AEGIS_DATABASE", "aegis.db")
