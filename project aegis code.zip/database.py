import sqlite3
from datetime import datetime, timezone
from config import DATABASE_PATH


def connect():
    conn = sqlite3.connect(DATABASE_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                cpu REAL NOT NULL,
                memory REAL NOT NULL,
                disk REAL NOT NULL,
                network_sent_mb REAL NOT NULL,
                network_recv_mb REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                metric TEXT NOT NULL,
                level TEXT NOT NULL,
                value REAL NOT NULL,
                message TEXT NOT NULL,
                resolved INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_timestamp ON metrics(timestamp)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp)")


def save_metrics(data):
    with connect() as conn:
        conn.execute("""
            INSERT INTO metrics
            (timestamp, cpu, memory, disk, network_sent_mb, network_recv_mb)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            data["timestamp"], data["cpu"], data["memory"], data["disk"],
            data["network_sent_mb"], data["network_recv_mb"]
        ))


def get_latest_metrics():
    with connect() as conn:
        row = conn.execute("SELECT * FROM metrics ORDER BY id DESC LIMIT 1").fetchone()
        return dict(row) if row else None


def get_metrics(limit=60):
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM metrics ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(row) for row in reversed(rows)]


def get_alerts(limit=30):
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM alerts ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(row) for row in rows]


def create_alert(metric, level, value, message):
    now = datetime.now(timezone.utc).isoformat()
    with connect() as conn:
        # Avoid inserting the same unresolved alert on every monitoring cycle.
        existing = conn.execute(
            "SELECT id FROM alerts WHERE metric=? AND resolved=0 LIMIT 1",
            (metric,)
        ).fetchone()
        if existing:
            conn.execute(
                "UPDATE alerts SET level=?, value=?, message=? WHERE id=?",
                (level, value, message, existing["id"])
            )
        else:
            conn.execute("""
                INSERT INTO alerts(timestamp, metric, level, value, message)
                VALUES (?, ?, ?, ?, ?)
            """, (now, metric, level, value, message))


def resolve_alert(metric):
    with connect() as conn:
        conn.execute(
            "UPDATE alerts SET resolved=1 WHERE metric=? AND resolved=0",
            (metric,)
        )


def get_summary():
    with connect() as conn:
        total = conn.execute("SELECT COUNT(*) AS n FROM metrics").fetchone()["n"]
        active = conn.execute(
            "SELECT COUNT(*) AS n FROM alerts WHERE resolved=0"
        ).fetchone()["n"]
        return {"samples_collected": total, "active_alerts": active}
