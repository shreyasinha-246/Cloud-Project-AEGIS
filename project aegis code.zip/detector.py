from config import (
    CPU_WARNING, CPU_CRITICAL,
    MEMORY_WARNING, MEMORY_CRITICAL,
    DISK_WARNING, DISK_CRITICAL
)
from database import create_alert, resolve_alert


def evaluate_metric(name, value, warning, critical):
    """Apply fixed thresholds. This is rule-based detection, not machine learning."""
    if value >= critical:
        level = "CRITICAL"
        message = f"{name} usage is critically high ({value:.1f}%)."
        create_alert(name, level, value, message)
    elif value >= warning:
        level = "WARNING"
        message = f"{name} usage is high ({value:.1f}%)."
        create_alert(name, level, value, message)
    else:
        resolve_alert(name)


def check_metrics(metrics):
    evaluate_metric("CPU", metrics["cpu"], CPU_WARNING, CPU_CRITICAL)
    evaluate_metric("Memory", metrics["memory"], MEMORY_WARNING, MEMORY_CRITICAL)
    evaluate_metric("Disk", metrics["disk"], DISK_WARNING, DISK_CRITICAL)
