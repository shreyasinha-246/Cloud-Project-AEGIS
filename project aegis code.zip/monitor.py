import threading
import time
from datetime import datetime, timezone

import psutil

from config import SAMPLE_INTERVAL
from database import save_metrics
from detector import check_metrics


class SystemMonitor:
    def __init__(self):
        self._stop_event = threading.Event()
        self._thread = None
        self._previous_net = psutil.net_io_counters()

    def collect(self):
        cpu = psutil.cpu_percent(interval=None)
        memory = psutil.virtual_memory().percent
        disk = psutil.disk_usage("/").percent
        net = psutil.net_io_counters()

        data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "cpu": round(cpu, 2),
            "memory": round(memory, 2),
            "disk": round(disk, 2),
            "network_sent_mb": round(net.bytes_sent / (1024 * 1024), 2),
            "network_recv_mb": round(net.bytes_recv / (1024 * 1024), 2),
        }
        return data

    def _run(self):
        # Prime CPU sampling so the first reading is meaningful.
        psutil.cpu_percent(interval=None)
        while not self._stop_event.is_set():
            try:
                metrics = self.collect()
                save_metrics(metrics)
                check_metrics(metrics)
            except Exception as exc:
                # Keep the monitoring thread alive if one sample fails.
                print(f"[AEGIS] Monitoring error: {exc}")
            self._stop_event.wait(SAMPLE_INTERVAL)

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        print("[AEGIS] Monitoring started.")

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2)
        print("[AEGIS] Monitoring stopped.")
